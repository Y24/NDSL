class CommandHandler {
 private:
  /* data */
 public:
  CommandHandler(/* args */);
  ~CommandHandler();
};

CommandHandler::CommandHandler(/* args */) {}

CommandHandler::~CommandHandler() {}
